<?php
// includes/mailer.php — reads SMTP credentials from the Settings table

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . '/phpmailer/Exception.php';
require_once __DIR__ . '/phpmailer/PHPMailer.php';
require_once __DIR__ . '/phpmailer/SMTP.php';

/**
 * Load SMTP settings from the database.
 * Returns ['email' => ..., 'password' => ..., 'shop_name' => ...]
 */
function ms_get_smtp_settings(): array {
    global $conn;
    $defaults = ['email' => '', 'password' => '', 'shop_name' => 'MotoStock26'];
    if (!$conn) return $defaults;

    $res = $conn->query("SELECT setting_key, setting_value FROM Settings WHERE setting_key IN ('smtp_email','smtp_password','shop_name')");
    if (!$res) return $defaults;

    while ($row = $res->fetch_assoc()) {
        if ($row['setting_key'] === 'smtp_email')    $defaults['email']     = $row['setting_value'] ?? '';
        if ($row['setting_key'] === 'smtp_password') $defaults['password']  = $row['setting_value'] ?? '';
        if ($row['setting_key'] === 'shop_name')     $defaults['shop_name'] = $row['setting_value'] ?? 'MotoStock26';
    }
    return $defaults;
}

/**
 * Returns true if SMTP has been configured.
 */
function ms_smtp_configured(): bool {
    $s = ms_get_smtp_settings();
    return !empty($s['email']) && !empty($s['password']);
}

function ms_send_email(string $to, string $subject, string $htmlBody): bool {
    if (empty($to) || !filter_var($to, FILTER_VALIDATE_EMAIL)) return false;

    $smtp = ms_get_smtp_settings();
    if (empty($smtp['email']) || empty($smtp['password'])) {
        error_log('MotoStock26 mailer: SMTP not configured. Go to User Info → Email Settings to set up.');
        return false;
    }

    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = $smtp['email'];
        $mail->Password   = $smtp['password'];
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        $mail->setFrom($smtp['email'], $smtp['shop_name']);
        $mail->addAddress($to);
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $htmlBody;

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log('Mailer error: ' . $mail->ErrorInfo);
        return false;
    }
}

function ms_email_template(string $title, string $body): string {
    $smtp     = ms_get_smtp_settings();
    $shopName = htmlspecialchars($smtp['shop_name'] ?: 'MotoStock26');
    return "
    <div style='font-family:Arial,sans-serif;max-width:560px;margin:0 auto;background:#f9f9f9;padding:24px;border-radius:10px;'>
      <div style='background:#1b2738;padding:16px 24px;border-radius:8px 8px 0 0;'>
        <span style='font-size:1.2rem;font-weight:800;color:#fff;'>{$shopName}</span>
      </div>
      <div style='background:#fff;padding:24px;border-radius:0 0 8px 8px;border:1px solid #e2e8f0;border-top:none;'>
        <h2 style='color:#1b2738;margin-top:0;font-size:1.1rem;'>{$title}</h2>
        {$body}
        <hr style='border:none;border-top:1px solid #e2e8f0;margin:20px 0;'>
        <p style='color:#94a3b8;font-size:.78rem;margin:0;'>This is an automated message from {$shopName}. Do not reply.</p>
      </div>
    </div>";
}