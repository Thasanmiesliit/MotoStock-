<?php
// includes/notify_events.php
// Call these functions at key events throughout the system.
// Requires: $conn (mysqli), mailer.php already included

require_once __DIR__ . '/mailer.php';

/**
 * Log a notification to the DB and optionally send email.
 */
function ms_notify(mysqli $conn, string $type, string $title, string $message, ?string $toEmail = null): void {
    $sent = 0;
    if ($toEmail && filter_var($toEmail, FILTER_VALIDATE_EMAIL)) {
        $html = ms_email_template($title, "<p style='color:#334155;'>{$message}</p>");
        $sent = ms_send_email($toEmail, $title, $html) ? 1 : 0;
    }
    $stmt = $conn->prepare("INSERT INTO notification (type, title, message, toEmail, emailSent, sentAt) VALUES (?, ?, ?, ?, ?, NOW())");
    $stmt->bind_param("ssssi", $type, $title, $message, $toEmail, $sent);
    $stmt->execute();
    $stmt->close();
}

/**
 * Trigger: Repair job status changed to Finished
 */
function notify_repair_finished(mysqli $conn, array $job): void {
    $customerName = 'Customer';
    $email        = null;

    // Try customerID first (most reliable)
    if (!empty($job['customerID'])) {
        $r = $conn->query("SELECT name, email FROM customer WHERE customerID = " . (int)$job['customerID'] . " LIMIT 1");
        if ($r && $r->num_rows > 0) {
            $c = $r->fetch_assoc();
            $customerName = $c['name'];
            $email        = $c['email'] ?: null;
        }
    }

    // Fallback — look up by vehicleNo if no customerID
    if (!$email && !empty($job['bikeNo'])) {
        $r = $conn->query("SELECT name, email FROM customer WHERE vehicleNo = '" . $conn->real_escape_string($job['bikeNo']) . "' LIMIT 1");
        if ($r && $r->num_rows > 0) {
            $c = $r->fetch_assoc();
            $customerName = $c['name'];
            $email        = $c['email'] ?: null;
        }
    }

    $title   = "Your Repair is Complete — {$job['bikeNo']}";
    $message = "Dear {$customerName}, your vehicle (No: {$job['bikeNo']}) has been repaired and is ready for collection. Reported issue: {$job['problemDescription']}";

    // Rich HTML email
    $body = "
        <p style='color:#334155;font-size:.95rem;'>Dear <strong>{$customerName}</strong>,</p>
        <p style='color:#334155;'>Great news! Your vehicle is repaired and ready for collection.</p>
        <table style='width:100%;border-collapse:collapse;margin:16px 0;font-size:.9rem;'>
            <tr style='background:#f1f5f9;'>
                <td style='padding:10px 14px;font-weight:600;border-bottom:1px solid #e2e8f0;'>Vehicle No.</td>
                <td style='padding:10px 14px;border-bottom:1px solid #e2e8f0;'>{$job['bikeNo']}</td>
            </tr>
            <tr>
                <td style='padding:10px 14px;font-weight:600;border-bottom:1px solid #e2e8f0;'>Issue Reported</td>
                <td style='padding:10px 14px;border-bottom:1px solid #e2e8f0;'>" . htmlspecialchars($job['problemDescription']) . "</td>
            </tr>
            <tr style='background:#f1f5f9;'>
                <td style='padding:10px 14px;font-weight:600;'>Status</td>
                <td style='padding:10px 14px;color:#16a34a;font-weight:700;'>✅ Finished</td>
            </tr>
        </table>
        <p style='color:#334155;'>Please visit us at your earliest convenience to collect your vehicle.</p>
        <p style='color:#94a3b8;font-size:.82rem;'>Thank you for choosing Bimsara Motors.</p>
    ";

    $html = ms_email_template($title, $body);

    $sent = 0;
    if ($email && filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $sent = ms_send_email($email, $title, $html) ? 1 : 0;
    }

    $type = 'repair_finished';
    $stmt = $conn->prepare("INSERT INTO notification (type, title, message, toEmail, emailSent, sentAt) VALUES (?, ?, ?, ?, ?, NOW())");
    $stmt->bind_param("ssssi", $type, $title, $message, $email, $sent);
    $stmt->execute();
    $stmt->close();
}

/**
 * Trigger: Part stock falls below minimum — sends summary email to owner
 */
function notify_low_stock_summary(mysqli $conn, array $parts): void {
    $ownerEmail = defined('OWNER_EMAIL') ? OWNER_EMAIL : null;
    $count  = count($parts);
    $title  = "Low Stock Summary — {$count} part(s) need reordering";

    // Build plain message for DB log
    $partNames = implode(', ', array_column($parts, 'partName'));
    $message   = "The following parts are below minimum stock: {$partNames}";

    $sent = 0;
    if ($ownerEmail && filter_var($ownerEmail, FILTER_VALIDATE_EMAIL)) {
        // Build HTML table
        $rows = '';
        foreach ($parts as $p) {
            $rows .= "<tr>
                <td style='padding:8px 12px;border-bottom:1px solid #e2e8f0;'>" . htmlspecialchars($p['partName']) . "</td>
                <td style='padding:8px 12px;border-bottom:1px solid #e2e8f0;color:#dc2626;font-weight:600;'>" . (int)$p['currentQuantity'] . "</td>
                <td style='padding:8px 12px;border-bottom:1px solid #e2e8f0;'>" . (int)$p['minQuantity'] . "</td>
            </tr>";
        }
        $body = "
            <p style='color:#334155;'>The following parts are currently below their minimum stock levels and require reordering:</p>
            <table style='width:100%;border-collapse:collapse;margin:12px 0;font-size:.9rem;'>
                <thead>
                    <tr style='background:#f1f5f9;'>
                        <th style='padding:8px 12px;text-align:left;border-bottom:2px solid #e2e8f0;'>Part Name</th>
                        <th style='padding:8px 12px;text-align:left;border-bottom:2px solid #e2e8f0;'>Current Qty</th>
                        <th style='padding:8px 12px;text-align:left;border-bottom:2px solid #e2e8f0;'>Min Qty</th>
                    </tr>
                </thead>
                <tbody>{$rows}</tbody>
            </table>
            <p style='color:#334155;'>Please reorder these parts as soon as possible.</p>
        ";
        $html = ms_email_template($title, $body);
        $sent = ms_send_email($ownerEmail, $title, $html) ? 1 : 0;
    }

    $type = 'low_stock';
    $stmt = $conn->prepare("INSERT INTO notification (type, title, message, toEmail, emailSent, sentAt) VALUES (?, ?, ?, ?, ?, NOW())");
    $stmt->bind_param("ssssi", $type, $title, $message, $ownerEmail, $sent);
    $stmt->execute();
    $stmt->close();
}

/**
 * Trigger: New sale completed
 */
function notify_sale_completed(mysqli $conn, int $saleID, string $customerName, float $total): void {
    $title   = "Sale Completed — Invoice #{$saleID}";
    $message = "A sale of Rs. " . number_format($total, 2) . " was completed for customer: {$customerName}.";
    ms_notify($conn, 'sale', $title, $message, null);
}

/**
 * Trigger: Service due reminder for a single customer
 */
function notify_service_due(mysqli $conn, array $customer): void {
    $title   = "Service Reminder — {$customer['name']}";
    $dueDate = date('d M Y', strtotime($customer['nextServiceDue']));
    $message = "Dear {$customer['name']}, your vehicle (No: {$customer['vehicleNo']}) was due for service on {$dueDate}. Please visit us at your earliest convenience.";
    ms_notify($conn, 'service_due', $title, $message, $customer['email'] ?? null);
}
