<?php

define('DB_HOST', 'localhost');
define('DB_USER', 'root');          
define('DB_PASS', '');              
define('DB_NAME', 'motostock26');

define('OWNER_EMAIL', 'codebravoecho11@gmail.com');
define('OWNER_SMTP_PASS', 'jznz zzgw xxhr bekk');

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");
