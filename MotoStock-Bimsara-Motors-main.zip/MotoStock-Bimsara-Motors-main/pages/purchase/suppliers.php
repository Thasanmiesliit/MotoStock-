<?php
session_start();
require_once '../../includes/config.php';
if (!isset($_SESSION['userID'])) { header("Location: ../../login.php"); exit; }
if (!in_array($_SESSION['role'], ['Owner', 'Cashier'])) { header("Location: ../../pages/dashboard.php"); exit; }

$errors  = [];
$success = '';

// ── Delete supplier ───────────────────────────────────────────────────────────
if (isset($_GET['delete']) && $_SESSION['role'] === 'Owner') {
    $delID = (int)$_GET['delete'];
    // Check if supplier has purchase orders
    $check = $conn->prepare("SELECT COUNT(*) as cnt FROM PurchaseOrder WHERE supplierID = ?");
    $check->bind_param("i", $delID);
    $check->execute();
    $cnt = $check->get_result()->fetch_assoc()['cnt'];
    if ($cnt > 0) {
        $errors['delete'] = "Cannot delete — this supplier has {$cnt} purchase order(s) linked.";
    } else {
        $conn->prepare("DELETE FROM Supplier WHERE supplierID = ?")->bind_param("i", $delID) && $conn->query("DELETE FROM Supplier WHERE supplierID = $delID");
        header("Location: suppliers.php?deleted=1"); exit;
    }
}

// ── Add / Edit supplier ───────────────────────────────────────────────────────
$editID       = isset($_GET['edit']) ? (int)$_GET['edit'] : 0;
$editSupplier = ['supplierName' => '', 'contact' => '', 'address' => ''];
if ($editID > 0) {
    $res = $conn->prepare("SELECT * FROM Supplier WHERE supplierID = ?");
    $res->bind_param("i", $editID); $res->execute();
    $row = $res->get_result()->fetch_assoc();
    if ($row) $editSupplier = $row;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postID   = (int)($_POST['supplierID'] ?? 0);
    $name     = trim($_POST['supplierName'] ?? '');
    $contact  = trim($_POST['contact']      ?? '');
    $address  = trim($_POST['address']      ?? '');

    // ── Validation ────────────────────────────────────────────────────────────
    if ($name === '') {
        $errors['supplierName'] = 'Supplier name is required.';
    } elseif (strlen($name) < 3) {
        $errors['supplierName'] = 'Name must be at least 3 characters.';
    } elseif (strlen($name) > 100) {
        $errors['supplierName'] = 'Name cannot exceed 100 characters.';
    }

    if ($contact !== '') {
        $cleanContact = preg_replace('/[\s\-]/', '', $contact);
        if (!preg_match('/^0[0-9]{9}$/', $cleanContact)) {
            $errors['contact'] = 'Enter a valid phone number (e.g. 0112345678).';
        }
    }

    if ($address !== '' && strlen($address) > 200) {
        $errors['address'] = 'Address cannot exceed 200 characters.';
    }

    // Check duplicate name (excluding self on edit)
    if (empty($errors['supplierName'])) {
        $dupCheck = $conn->prepare("SELECT supplierID FROM Supplier WHERE supplierName = ? AND supplierID != ?");
        $dupCheck->bind_param("si", $name, $postID); $dupCheck->execute();
        if ($dupCheck->get_result()->num_rows > 0) {
            $errors['supplierName'] = 'A supplier with this name already exists.';
        }
    }

    if (empty($errors)) {
        if ($postID > 0) {
            // Update
            $stmt = $conn->prepare("UPDATE Supplier SET supplierName=?, contact=?, address=? WHERE supplierID=?");
            $stmt->bind_param("sssi", $name, $contact, $address, $postID);
            $stmt->execute();
            header("Location: suppliers.php?updated=1"); exit;
        } else {
            // Insert
            $stmt = $conn->prepare("INSERT INTO Supplier (supplierName, contact, address) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $name, $contact, $address);
            $stmt->execute();
            header("Location: suppliers.php?added=1"); exit;
        }
    }

    // Repopulate on error
    $editSupplier = ['supplierName' => $name, 'contact' => $contact, 'address' => $address];
    $editID = $postID;
}

// ── Load all suppliers ────────────────────────────────────────────────────────
$suppliers = $conn->query("
    SELECT s.*, COUNT(po.poID) as orderCount, IFNULL(SUM(po.totalCost),0) as totalSpend
    FROM Supplier s
    LEFT JOIN PurchaseOrder po ON po.supplierID = s.supplierID
    GROUP BY s.supplierID
    ORDER BY s.supplierName ASC
");

$currentPage = 'purchase';
$base = '../../';
$pageTitle = $editID > 0 ? 'Edit Supplier' : 'Add New Supplier';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <script>/* Anti-FOUC */(function(){var t=localStorage.getItem("ms26_theme")||"light";document.documentElement.setAttribute("data-theme",t);})();</script>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Suppliers — MotoStock26</title>
  <link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../../assets/css/styles.css">
</head>
<body>
<?php require_once '../../includes/sidebar.php'; ?>

<div class="main-wrap">
  <div class="topbar">
    <div>
      <div class="topbar-title">Suppliers</div>
      <div class="topbar-breadcrumb">Purchase Orders → Manage Suppliers</div>
    </div>
    <a href="list.php" class="btn btn-secondary btn-sm">← Purchase Orders</a>
  </div>

  <div class="main-content">

    <?php if (isset($_GET['added'])):   ?><div class="alert alert-success">✅ Supplier added successfully!</div><?php endif; ?>
    <?php if (isset($_GET['updated'])): ?><div class="alert alert-success">✅ Supplier updated successfully!</div><?php endif; ?>
    <?php if (isset($_GET['deleted'])): ?><div class="alert alert-warning">🗑 Supplier deleted.</div><?php endif; ?>
    <?php if (isset($errors['delete'])): ?><div class="alert alert-danger">⚠ <?= htmlspecialchars($errors['delete']) ?></div><?php endif; ?>

    <div style="display:grid; grid-template-columns:380px 1fr; gap:24px; align-items:start;">

      <!-- ── ADD / EDIT FORM ─────────────────────────────────────────────── -->
      <div class="card">
        <div class="card-header"><?= $editID > 0 ? '✏️ Edit Supplier' : '+ Add New Supplier' ?></div>
        <div class="card-body">

          <?php if (!empty($errors) && !isset($errors['delete'])): ?>
            <div class="alert alert-danger">⚠ Please fix the errors below.</div>
          <?php endif; ?>

          <form method="post" id="supplierForm" novalidate>
            <input type="hidden" name="supplierID" value="<?= $editID ?>">

            <div class="form-group">
              <label class="form-label">Supplier Name *</label>
              <input type="text" name="supplierName" id="supName"
                     class="form-control <?= isset($errors['supplierName']) ? 'is-invalid' : '' ?>"
                     value="<?= htmlspecialchars($editSupplier['supplierName']) ?>"
                     placeholder="e.g. Lanka Auto Parts" maxlength="100">
              <span class="field-error" id="supNameErr"><?= htmlspecialchars($errors['supplierName'] ?? '') ?></span>
            </div>

            <div class="form-group">
              <label class="form-label">Contact Number <span style="font-size:.72rem;color:var(--muted)">(optional)</span></label>
              <input type="text" name="contact" id="supContact"
                     class="form-control <?= isset($errors['contact']) ? 'is-invalid' : '' ?>"
                     value="<?= htmlspecialchars($editSupplier['contact']) ?>"
                     placeholder="e.g. 0112345678" maxlength="20">
              <span class="field-error" id="supContactErr"><?= htmlspecialchars($errors['contact'] ?? '') ?></span>
            </div>

            <div class="form-group">
              <label class="form-label">Address <span style="font-size:.72rem;color:var(--muted)">(optional)</span></label>
              <textarea name="address" id="supAddress" rows="2"
                        class="form-control <?= isset($errors['address']) ? 'is-invalid' : '' ?>"
                        placeholder="e.g. 45 Baseline Road, Colombo 09"
                        maxlength="200"><?= htmlspecialchars($editSupplier['address']) ?></textarea>
              <div class="char-counter" id="addrCounter">0 / 200</div>
              <span class="field-error" id="supAddressErr"><?= htmlspecialchars($errors['address'] ?? '') ?></span>
            </div>

            <div class="d-flex gap-2 mt-2">
              <button type="submit" class="btn btn-amber">
                <?= $editID > 0 ? 'Save Changes' : 'Add Supplier' ?>
              </button>
              <?php if ($editID > 0): ?>
              <a href="suppliers.php" class="btn btn-secondary">Cancel</a>
              <?php endif; ?>
            </div>
          </form>

          <?php if ($editID === 0): ?>
          <div style="margin-top:18px;padding-top:14px;border-top:1px solid var(--border);font-size:.78rem;color:var(--muted);">
            💡 After adding a supplier you can select them when creating a new Purchase Order.
          </div>
          <?php endif; ?>
        </div>
      </div>

      <!-- ── SUPPLIERS TABLE ────────────────────────────────────────────── -->
      <div class="card">
        <div class="card-header">
          <span>All Suppliers</span>
          <span style="font-size:.75rem;color:var(--muted);"><?= $suppliers->num_rows ?> supplier(s)</span>
        </div>
        <div class="table-wrap" style="border:none;box-shadow:none;border-radius:0;">
          <table class="table">
            <thead>
              <tr>
                <th>Supplier Name</th>
                <th>Contact</th>
                <th>Address</th>
                <th>Orders</th>
                <th>Total Spend</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
            <?php if ($suppliers->num_rows === 0): ?>
            <tr>
              <td colspan="6" style="text-align:center;color:var(--muted);padding:28px;">
                No suppliers yet. Add your first supplier using the form.
              </td>
            </tr>
            <?php else: while ($sup = $suppliers->fetch_assoc()): ?>
            <tr>
              <td><strong><?= htmlspecialchars($sup['supplierName']) ?></strong></td>
              <td><?= $sup['contact'] ? htmlspecialchars($sup['contact']) : '<span class="text-muted">—</span>' ?></td>
              <td style="font-size:.8rem;max-width:180px;">
                <?= $sup['address'] ? htmlspecialchars($sup['address']) : '<span class="text-muted">—</span>' ?>
              </td>
              <td>
                <?php if ($sup['orderCount'] > 0): ?>
                  <a href="list.php" class="badge badge-info" style="text-decoration:none;">
                    <?= $sup['orderCount'] ?> order<?= $sup['orderCount'] > 1 ? 's' : '' ?>
                  </a>
                <?php else: ?>
                  <span class="text-muted">None</span>
                <?php endif; ?>
              </td>
              <td>
                <?php if ($sup['totalSpend'] > 0): ?>
                  <strong>Rs. <?= number_format($sup['totalSpend'], 2) ?></strong>
                <?php else: ?>
                  <span class="text-muted">—</span>
                <?php endif; ?>
              </td>
              <td>
                <div class="d-flex gap-2">
                  <a href="suppliers.php?edit=<?= $sup['supplierID'] ?>"
                     class="btn btn-sm btn-warning">Edit</a>
                  <?php if ($_SESSION['role'] === 'Owner'): ?>
                  <a href="suppliers.php?delete=<?= $sup['supplierID'] ?>"
                     class="btn btn-sm btn-danger"
                     onclick="return confirm('Delete <?= htmlspecialchars(addslashes($sup['supplierName'])) ?>? This cannot be undone.')">
                    Delete
                  </a>
                  <?php endif; ?>
                  <a href="create.php?supplierID=<?= $sup['supplierID'] ?>"
                     class="btn btn-sm btn-outline" title="New PO for this supplier">+ PO</a>
                </div>
              </td>
            </tr>
            <?php endwhile; endif; ?>
            </tbody>
          </table>
        </div>
      </div>

    </div>
  </div>
</div>

<script src="../../assets/js/validation.js"></script>
<script>
const supNameEl    = document.getElementById('supName');
const supContactEl = document.getElementById('supContact');
const supAddrEl    = document.getElementById('supAddress');

// Name: required, 3–100 chars
msLiveValidate(supNameEl, 'supNameErr', function(val) {
  val = val.trim();
  if (val === '')        return 'Supplier name is required.';
  if (val.length < 3)    return 'Name must be at least 3 characters.';
  if (val.length > 100)  return 'Name cannot exceed 100 characters.';
  return '';
});

// Contact: optional, valid phone if entered
msLiveValidate(supContactEl, 'supContactErr', function(val) {
  const clean = val.trim().replace(/[\s\-]/g, '');
  if (clean === '') return '';
  if (!/^0[0-9]{9}$/.test(clean)) return 'Enter a valid 10-digit number starting with 0.';
  return '';
});

// Address: optional, max 200 chars
msCharCounter(supAddrEl, 'addrCounter', 200);
msLiveValidate(supAddrEl, 'supAddressErr', function(val) {
  if (val.length > 200) return 'Address cannot exceed 200 characters.';
  return '';
});

// Submit
document.getElementById('supplierForm').addEventListener('submit', function(e) {
  const v1 = msSetError(supNameEl, 'supNameErr', (function(val) {
    val = val.trim();
    if (val === '')       return 'Supplier name is required.';
    if (val.length < 3)   return 'Name must be at least 3 characters.';
    if (val.length > 100) return 'Name cannot exceed 100 characters.';
    return '';
  })(supNameEl.value));

  const v2 = msSetError(supContactEl, 'supContactErr', (function(val) {
    const clean = val.trim().replace(/[\s\-]/g, '');
    if (clean === '') return '';
    if (!/^0[0-9]{9}$/.test(clean)) return 'Enter a valid 10-digit number starting with 0.';
    return '';
  })(supContactEl.value));

  const v3 = msSetError(supAddrEl, 'supAddressErr',
    supAddrEl.value.length > 200 ? 'Address cannot exceed 200 characters.' : '');

  if (!v1 || !v2 || !v3) e.preventDefault();
});
</script>
</body>
</html>