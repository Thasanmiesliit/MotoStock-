<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/mailer.php';

if (!isset($_SESSION['userID'])) { header("Location: ../login.php"); exit; }

$currentPage = 'user';
$base        = '../';
$username    = $_SESSION['username'] ?? 'Unknown';
$role        = $_SESSION['role']     ?? 'Employee';
$userId      = (int)($_SESSION['userID'] ?? 0);
$isOwner     = ($role === 'Owner');
$error       = '';
$success     = '';
$emailSuccess= '';
$emailError  = '';

$roleOptions = ['Owner', 'Cashier', 'Employee'];
$dbRoleResult = $conn->query("SELECT DISTINCT role FROM User WHERE role IS NOT NULL AND role != '' ORDER BY role");
if ($dbRoleResult) {
    while ($r = $dbRoleResult->fetch_assoc()) {
        $dbRole = trim((string)$r['role']);
        if ($dbRole !== '' && !in_array($dbRole, $roleOptions, true)) $roleOptions[] = $dbRole;
    }
}
sort($roleOptions);

// ── Load current email settings ───────────────────────────────────────────────
$smtpSettings = ms_get_smtp_settings();
$smtpEmail    = $smtpSettings['email']     ?? '';
$smtpPass     = $smtpSettings['password']  ?? '';
$shopName     = $smtpSettings['shop_name'] ?? 'MotoStock26';
$isConfigured = !empty($smtpEmail) && !empty($smtpPass);

// ── Handle POST ───────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    // ── Save email settings (Owner only) ──────────────────────────────────────
    if ($action === 'save_email_settings' && $isOwner) {
        $newEmail    = trim($_POST['smtp_email']    ?? '');
        $newPass     = trim($_POST['smtp_password'] ?? '');
        $newShopName = trim($_POST['shop_name']     ?? '');

        if ($newEmail === '') {
            $emailError = 'Gmail address is required.';
        } elseif (!filter_var($newEmail, FILTER_VALIDATE_EMAIL)) {
            $emailError = 'Please enter a valid email address.';
        } elseif (!str_ends_with(strtolower($newEmail), '@gmail.com')) {
            $emailError = 'Only Gmail addresses are supported (must end with @gmail.com).';
        } elseif ($newPass === '') {
            $emailError = 'App password is required.';
        } elseif (strlen(str_replace(' ', '', $newPass)) !== 16) {
            $emailError = 'Google App Password must be exactly 16 characters (spaces are OK).';
        } elseif ($newShopName === '') {
            $emailError = 'Shop name is required.';
        } else {
            // Save all three settings
            $keys = ['smtp_email' => $newEmail, 'smtp_password' => $newPass, 'shop_name' => $newShopName];
            foreach ($keys as $k => $v) {
                $stmt = $conn->prepare("INSERT INTO Settings (setting_key, setting_value) VALUES (?,?) ON DUPLICATE KEY UPDATE setting_value=?");
                $stmt->bind_param("sss", $k, $v, $v);
                $stmt->execute();
            }
            $emailSuccess = 'Email settings saved! Notifications will now be sent from ' . htmlspecialchars($newEmail) . '.';
            // Refresh
            $smtpSettings = ms_get_smtp_settings();
            $smtpEmail    = $smtpSettings['email'];
            $smtpPass     = $smtpSettings['password'];
            $shopName     = $smtpSettings['shop_name'];
            $isConfigured = !empty($smtpEmail) && !empty($smtpPass);
        }
    }

    // ── Test email ────────────────────────────────────────────────────────────
    elseif ($action === 'test_email' && $isOwner) {
        if (!$isConfigured) {
            $emailError = 'Please save your email settings first before sending a test.';
        } else {
            $html  = ms_email_template('Test Email', '<p>This is a test email from <strong>' . htmlspecialchars($shopName) . '</strong>. Your email notifications are working correctly!</p>');
            $sent  = ms_send_email($smtpEmail, 'MotoStock26 — Test Email', $html);
            if ($sent) $emailSuccess = '✅ Test email sent to ' . htmlspecialchars($smtpEmail) . '. Check your inbox.';
            else       $emailError   = '❌ Test failed. Check that your Gmail and App Password are correct.';
        }
    }

    // ── Create user ───────────────────────────────────────────────────────────
    elseif ($action === 'create_user' && $isOwner) {
        $createUsername = trim($_POST['create_username'] ?? '');
        $createPassword = trim($_POST['create_password'] ?? '');
        $createRole     = trim($_POST['create_role']     ?? 'Employee');

        if ($createUsername===''||$createPassword===''||$createRole==='') {
            $error = 'Username, password, and role are required.';
        } elseif (strlen($createUsername)<3||strlen($createUsername)>40) {
            $error = 'Username must be 3–40 characters.';
        } elseif (!preg_match('/^[A-Za-z0-9_\.\-]+$/', $createUsername)) {
            $error = 'Username: letters, numbers, underscores, dots and hyphens only.';
        } elseif (strlen($createPassword)<4||strlen($createPassword)>100) {
            $error = 'Password must be 4–100 characters.';
        } elseif (!in_array($createRole,$roleOptions,true)) {
            $error = 'Invalid role.';
        } else {
            $dup = $conn->prepare("SELECT userID FROM User WHERE username=?");
            $dup->bind_param("s",$createUsername); $dup->execute();
            if ($dup->get_result()->num_rows>0) {
                $error = 'That username is already taken.';
            } else {
                $hp   = password_hash($createPassword, PASSWORD_BCRYPT);
                $stmt = $conn->prepare("INSERT INTO User (username,password,role) VALUES (?,?,?)");
                $stmt->bind_param("sss",$createUsername,$hp,$createRole);
                $success = $stmt->execute() ? 'New account created.' : 'Could not create account.';
            }
        }
    }

    // ── Update user ───────────────────────────────────────────────────────────
    elseif ($action === 'update_user' && $isOwner) {
        $tid = (int)($_POST['target_user_id']??0);
        $nu  = trim($_POST['new_username']??'');
        $np  = trim($_POST['new_password']??'');
        $nr  = trim($_POST['new_role']??'');

        if ($tid<=0||$nu===''||$np===''||$nr==='') { $error='All fields required.'; }
        elseif (strlen($nu)<3||strlen($nu)>40)     { $error='Username must be 3–40 characters.'; }
        elseif (!preg_match('/^[A-Za-z0-9_\.\-]+$/',$nu)) { $error='Invalid username characters.'; }
        elseif (strlen($np)<4||strlen($np)>100)    { $error='Password must be 4–100 characters.'; }
        elseif (!in_array($nr,$roleOptions,true))  { $error='Invalid role.'; }
        else {
            $dup=$conn->prepare("SELECT userID FROM User WHERE username=? AND userID!=?");
            $dup->bind_param("si",$nu,$tid); $dup->execute();
            if ($dup->get_result()->num_rows>0) { $error='Username already taken.'; }
            else {
                $hp=$password_hash($np,PASSWORD_BCRYPT);
                $stmt=$conn->prepare("UPDATE User SET username=?,password=?,role=? WHERE userID=?");
                $stmt->bind_param("sssi",$nu,$hp,$nr,$tid);
                if ($stmt->execute()) {
                    if ($tid===$userId) { $_SESSION['username']=$nu; $_SESSION['role']=$nr; $username=$nu; $role=$nr; $isOwner=($nr==='Owner'); }
                    $success='Account updated.';
                } else { $error='Could not update account.'; }
            }
        }
    }

    // ── Delete user ───────────────────────────────────────────────────────────
    elseif ($action === 'delete_user' && $isOwner) {
        $tid=(int)($_POST['target_user_id']??0);
        if ($tid<=0) { $error='Invalid account.'; }
        else {
            $rs=$conn->prepare("SELECT role FROM User WHERE userID=?"); $rs->bind_param("i",$tid); $rs->execute();
            $tu=$rs->get_result()->fetch_assoc();
            if (!$tu)                      { $error='Account not found.'; }
            elseif ($tu['role']==='Owner') { $error='Owner accounts cannot be deleted.'; }
            elseif ($tid===$userId)        { $error='Cannot delete your own account.'; }
            else {
                $ds=$conn->prepare("DELETE FROM User WHERE userID=?"); $ds->bind_param("i",$tid);
                $success=$ds->execute()?'Account deleted.':'Could not delete.';
            }
        }
    }
}

$users = [];
if ($isOwner) {
    $ur = $conn->query("SELECT userID,username,password,role FROM User ORDER BY username ASC");
    if ($ur) while ($u=$ur->fetch_assoc()) $users[]=$u;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <script>/* Anti-FOUC */(function(){var t=localStorage.getItem("ms26_theme")||"light";document.documentElement.setAttribute("data-theme",t);})();</script>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>User Info — MotoStock26</title>
  <link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/styles.css">
  <style>
    .setup-step { display:flex; gap:14px; align-items:flex-start; padding:12px 0; border-bottom:1px solid var(--border); }
    .setup-step:last-child { border-bottom:none; }
    .step-num { width:28px; height:28px; border-radius:50%; background:var(--accent); color:#fff; font-family:'Syne',sans-serif; font-weight:800; font-size:.82rem; display:flex; align-items:center; justify-content:center; flex-shrink:0; margin-top:1px; }
    .step-body { flex:1; }
    .step-body strong { display:block; font-size:.88rem; color:var(--text); margin-bottom:3px; }
    .step-body span { font-size:.8rem; color:var(--muted); line-height:1.5; }
    .step-body code { background:var(--surface-2); border:1px solid var(--border); border-radius:4px; padding:1px 6px; font-size:.78rem; color:var(--accent); }
    .smtp-status-dot { width:9px; height:9px; border-radius:50%; display:inline-block; margin-right:6px; }
    .smtp-status-dot.ok  { background:#22c55e; }
    .smtp-status-dot.bad { background:#ef4444; }
  </style>
</head>
<body>
<?php require_once '../includes/sidebar.php'; ?>

<div class="main-wrap">
  <div class="topbar">
    <div>
      <div class="topbar-title">User Info</div>
      <div class="topbar-breadcrumb">Account details &amp; settings</div>
    </div>
  </div>

  <div class="main-content">

    <!-- Profile -->
    <div class="card" style="max-width:520px;">
      <div class="card-header">Profile</div>
      <div class="card-body">
        <div class="form-group">
          <label class="form-label">Username</label>
          <div class="form-control"><?= htmlspecialchars($username) ?></div>
        </div>
        <div class="form-group" style="margin-bottom:0;">
          <label class="form-label">Role</label>
          <div class="form-control"><?= htmlspecialchars($role) ?></div>
        </div>
      </div>
    </div>

    <?php if ($isOwner): ?>

    <!-- ── EMAIL / NOTIFICATION SETTINGS ─────────────────────────────────── -->
    <div class="card mt-3" style="max-width:720px;">
      <div class="card-header">
        <span>✉️ Email &amp; Notification Settings</span>
        <span style="font-size:.78rem;">
          <span class="smtp-status-dot <?= $isConfigured?'ok':'bad' ?>"></span>
          <?= $isConfigured ? 'Configured' : 'Not set up' ?>
        </span>
      </div>
      <div class="card-body">

        <?php if ($emailError):  ?><div class="alert alert-danger">⚠ <?= htmlspecialchars($emailError) ?></div><?php endif; ?>
        <?php if ($emailSuccess): ?><div class="alert alert-success">✅ <?= $emailSuccess ?></div><?php endif; ?>

        <?php if (!$isConfigured): ?>
        <!-- Setup guide shown when not configured -->
        <div class="alert" style="background:rgba(245,158,11,.1);border:1px solid rgba(245,158,11,.3);color:var(--text);border-radius:8px;margin-bottom:20px;">
          <strong style="font-size:.88rem;">⚠ Email notifications are not set up yet.</strong>
          <span style="font-size:.82rem;color:var(--muted);display:block;margin-top:2px;">Follow the steps below to enable automatic emails for service reminders, low stock alerts and sale notifications.</span>
        </div>

        <div style="margin-bottom:22px;">
          <div style="font-family:'Syne',sans-serif;font-weight:700;font-size:.88rem;margin-bottom:12px;color:var(--text);">
            📋 How to set up Gmail for notifications
          </div>
          <div class="setup-step">
            <div class="step-num">1</div>
            <div class="step-body">
              <strong>Use a Gmail account</strong>
              <span>You need a Gmail address (e.g. <code>yourshop@gmail.com</code>). You can use your existing Gmail or create a new one at <code>gmail.com</code>. Do <strong>not</strong> use your personal password below — you need an App Password (step 3).</span>
            </div>
          </div>
          <div class="setup-step">
            <div class="step-num">2</div>
            <div class="step-body">
              <strong>Enable 2-Step Verification on that Gmail</strong>
              <span>Go to <code>myaccount.google.com</code> → Security → 2-Step Verification → Turn it on. This is required before you can create an App Password.</span>
            </div>
          </div>
          <div class="setup-step">
            <div class="step-num">3</div>
            <div class="step-body">
              <strong>Create a Google App Password</strong>
              <span>Go to <code>myaccount.google.com</code> → Security → App passwords (search for it). Choose App: <code>Mail</code>, Device: <code>Windows Computer</code>. Click Generate. Google will show a <strong>16-character password</strong> (e.g. <code>abcd efgh ijkl mnop</code>). Copy it — you only see it once.</span>
            </div>
          </div>
          <div class="setup-step">
            <div class="step-num">4</div>
            <div class="step-body">
              <strong>Enter your Gmail and App Password below</strong>
              <span>Paste your Gmail address and the 16-character App Password into the form below. Spaces in the App Password are fine. Click <strong>Save Settings</strong>, then <strong>Send Test Email</strong> to confirm it works.</span>
            </div>
          </div>
        </div>
        <?php endif; ?>

        <!-- Settings form -->
        <form method="post" id="emailSettingsForm" novalidate>
          <input type="hidden" name="action" value="save_email_settings">
          <div class="form-grid-2">
            <div class="form-group">
              <label class="form-label">Gmail Address *</label>
              <input type="email" name="smtp_email" id="smtpEmail" class="form-control"
                     value="<?= htmlspecialchars($smtpEmail) ?>"
                     placeholder="yourshop@gmail.com" maxlength="100">
              <span class="field-error" id="smtpEmailErr" style="display:none"></span>
            </div>
            <div class="form-group">
              <label class="form-label">
                Google App Password *
                <span style="font-size:.72rem;color:var(--muted)">(16 chars from Google — not your login password)</span>
              </label>
              <div style="display:flex;gap:8px;align-items:center;">
                <input type="password" name="smtp_password" id="smtpPass" class="form-control"
                       value="<?= htmlspecialchars($smtpPass) ?>"
                       placeholder="xxxx xxxx xxxx xxxx" maxlength="20">
                <button type="button" class="btn btn-sm btn-outline" id="toggleSmtpPass">👁</button>
              </div>
              <span class="field-error" id="smtpPassErr" style="display:none"></span>
            </div>
          </div>
          <div class="form-group" style="max-width:320px;">
            <label class="form-label">Shop / Business Name</label>
            <input type="text" name="shop_name" id="shopName" class="form-control"
                   value="<?= htmlspecialchars($shopName) ?>"
                   placeholder="e.g. Bimsara Motors" maxlength="60">
            <span style="font-size:.75rem;color:var(--muted);margin-top:4px;display:block;">This name appears in all outgoing emails.</span>
          </div>
          <div class="d-flex gap-2 mt-2">
            <button type="submit" class="btn btn-amber">Save Settings</button>
            <?php if ($isConfigured): ?>
            <button type="submit" name="action" value="test_email" form="testEmailForm" class="btn btn-outline">
              📧 Send Test Email
            </button>
            <?php endif; ?>
          </div>
        </form>
        <form method="post" id="testEmailForm">
          <input type="hidden" name="action" value="test_email">
        </form>

        <?php if ($isConfigured): ?>
        <div style="margin-top:16px;padding-top:14px;border-top:1px solid var(--border);font-size:.8rem;color:var(--muted);">
          ✅ Emails will be sent from <strong><?= htmlspecialchars($smtpEmail) ?></strong>
          as <strong><?= htmlspecialchars($shopName) ?></strong>.
          To change the credentials, update the fields above and click Save Settings.
        </div>
        <?php endif; ?>

      </div>
    </div>

    <!-- ── MANAGE USER ACCOUNTS ───────────────────────────────────────────── -->
    <div class="card mt-3">
      <div class="card-header">Manage User Accounts <span style="font-size:.75rem;font-weight:400;color:var(--muted)">(Owner only)</span></div>
      <div class="card-body">
        <?php if ($error):   ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
        <?php if ($success): ?><div class="alert alert-success"><?= htmlspecialchars($success) ?></div><?php endif; ?>

        <!-- Create account -->
        <div class="card mb-2" style="box-shadow:none;">
          <div class="card-header">Create New Account</div>
          <div class="card-body">
            <form method="post" class="form-grid-3">
              <div class="form-group" style="margin-bottom:0;">
                <label class="form-label">Username</label>
                <input type="text" name="create_username" class="form-control" required>
              </div>
              <div class="form-group" style="margin-bottom:0;">
                <label class="form-label">Password</label>
                <input type="text" name="create_password" class="form-control" required>
              </div>
              <div class="form-group" style="margin-bottom:0;">
                <label class="form-label">Role</label>
                <select name="create_role" class="form-control">
                  <?php foreach ($roleOptions as $opt): ?>
                  <option value="<?= htmlspecialchars($opt) ?>" <?= $opt==='Employee'?'selected':'' ?>><?= htmlspecialchars($opt) ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <input type="hidden" name="action" value="create_user">
              <div style="grid-column:1/-1;">
                <button type="submit" class="btn btn-success">Create Account</button>
              </div>
            </form>
          </div>
        </div>

        <!-- Users table -->
        <div class="table-wrap" style="box-shadow:none;">
          <table class="table">
            <thead>
              <tr><th>ID</th><th>Username</th><th>Password</th><th>Role</th><th>Actions</th></tr>
            </thead>
            <tbody>
            <?php foreach ($users as $u): ?>
            <tr>
              <td><?= (int)$u['userID'] ?></td>
              <td>
                <input type="text" name="new_username" class="form-control" style="min-width:160px;"
                       form="upd-<?= (int)$u['userID'] ?>" value="<?= htmlspecialchars($u['username']) ?>" required>
              </td>
              <td>
                <div style="display:flex;gap:6px;align-items:center;min-width:200px;">
                  <input type="password" name="new_password" class="form-control js-password-field"
                         form="upd-<?= (int)$u['userID'] ?>" value="<?= htmlspecialchars($u['password']) ?>" required>
                  <button type="button" class="btn btn-sm btn-outline js-toggle-password">👁</button>
                </div>
              </td>
              <td>
                <select name="new_role" class="form-control" style="min-width:130px;" form="upd-<?= (int)$u['userID'] ?>">
                  <?php foreach ($roleOptions as $opt): ?>
                  <option value="<?= htmlspecialchars($opt) ?>" <?= $u['role']===$opt?'selected':'' ?>><?= htmlspecialchars($opt) ?></option>
                  <?php endforeach; ?>
                </select>
              </td>
              <td>
                <form id="upd-<?= (int)$u['userID'] ?>" method="post" style="display:inline-block;">
                  <input type="hidden" name="action" value="update_user">
                  <input type="hidden" name="target_user_id" value="<?= (int)$u['userID'] ?>">
                  <button type="submit" class="btn btn-sm btn-primary">Update</button>
                </form>
                <?php if (($u['role']??'')!=='Owner'): ?>
                <form method="post" style="display:inline-block;margin-top:4px;"
                      onsubmit="return confirm('Delete this account?')">
                  <input type="hidden" name="action" value="delete_user">
                  <input type="hidden" name="target_user_id" value="<?= (int)$u['userID'] ?>">
                  <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                </form>
                <?php endif; ?>
              </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <?php endif; // isOwner ?>

  </div>
</div>

<script>
// ── Password visibility toggles ───────────────────────────────────────────────
document.querySelectorAll('.js-toggle-password').forEach(function(btn) {
  btn.addEventListener('click', function() {
    var inp = btn.closest('td')?.querySelector('.js-password-field');
    if (!inp) return;
    inp.type = inp.type === 'password' ? 'text' : 'password';
    btn.textContent = inp.type === 'text' ? '🙈' : '👁';
  });
});

// SMTP password visibility toggle
document.getElementById('toggleSmtpPass')?.addEventListener('click', function() {
  var inp = document.getElementById('smtpPass');
  if (!inp) return;
  inp.type = inp.type === 'password' ? 'text' : 'password';
  this.textContent = inp.type === 'text' ? '🙈' : '👁';
});

// ── Email settings validation ─────────────────────────────────────────────────
function showErr(id, msg) {
  var el = document.getElementById(id);
  if (!el) return !msg;
  el.textContent = msg; el.style.display = msg ? 'block' : 'none';
  return !msg;
}

var smtpEmailEl = document.getElementById('smtpEmail');
var smtpPassEl  = document.getElementById('smtpPass');

if (smtpEmailEl) {
  smtpEmailEl.addEventListener('blur', function() {
    var v = smtpEmailEl.value.trim();
    if (!v) return showErr('smtpEmailErr', 'Gmail address is required.');
    if (!/^[^\s@]+@gmail\.com$/i.test(v)) return showErr('smtpEmailErr', 'Must be a Gmail address ending in @gmail.com.');
    showErr('smtpEmailErr', '');
  });
}

if (smtpPassEl) {
  smtpPassEl.addEventListener('blur', function() {
    var v = smtpPassEl.value.replace(/\s/g, '');
    if (!v) return showErr('smtpPassErr', 'App password is required.');
    if (v.length !== 16) return showErr('smtpPassErr', 'App password must be exactly 16 characters.');
    showErr('smtpPassErr', '');
  });
}

document.getElementById('emailSettingsForm')?.addEventListener('submit', function(e) {
  var email = (smtpEmailEl?.value||'').trim();
  var pass  = (smtpPassEl?.value||'').replace(/\s/g,'');
  var valid = true;
  if (!email || !/^[^\s@]+@gmail\.com$/i.test(email)) { showErr('smtpEmailErr','Must be a valid @gmail.com address.'); valid=false; }
  else showErr('smtpEmailErr','');
  if (!pass) { showErr('smtpPassErr','App password is required.'); valid=false; }
  else if (pass.length!==16) { showErr('smtpPassErr','App password must be exactly 16 characters.'); valid=false; }
  else showErr('smtpPassErr','');
  if (!valid) e.preventDefault();
});

// ── User table validation ─────────────────────────────────────────────────────
function validateUserField(inp, errId, rules) {
  const val = inp.value.trim();
  let msg = '';
  for (const rule of rules) { if (!rule.test(val)) { msg = rule.msg; break; } }
  let errEl = document.getElementById(errId);
  if (!errEl) { errEl=document.createElement('span'); errEl.id=errId; errEl.className='field-error'; inp.parentNode.appendChild(errEl); }
  if (msg) { inp.classList.add('is-invalid'); errEl.textContent=msg; errEl.style.display='block'; return false; }
  inp.classList.remove('is-invalid'); inp.classList.add('is-valid'); errEl.style.display='none';
  return true;
}
const usernameRules = [
  { test: v=>v.length>=3,  msg:'Username must be at least 3 characters.' },
  { test: v=>v.length<=40, msg:'Username cannot exceed 40 characters.' },
  { test: v=>/^[A-Za-z0-9_.\-]+$/.test(v), msg:'Letters, numbers, underscores, dots and hyphens only.' }
];
const passwordRules = [
  { test: v=>v.length>=4,   msg:'Password must be at least 4 characters.' },
  { test: v=>v.length<=100, msg:'Password cannot exceed 100 characters.' }
];
const createForm = document.querySelector('form input[name="action"][value="create_user"]')?.closest('form');
if (createForm) {
  const uInp=createForm.querySelector('input[name="create_username"]');
  const pInp=createForm.querySelector('input[name="create_password"]');
  if(uInp) uInp.addEventListener('blur',()=>validateUserField(uInp,'createUsernameErr',usernameRules));
  if(pInp) pInp.addEventListener('blur',()=>validateUserField(pInp,'createPasswordErr',passwordRules));
  createForm.addEventListener('submit',function(e){
    const v1=uInp?validateUserField(uInp,'createUsernameErr',usernameRules):true;
    const v2=pInp?validateUserField(pInp,'createPasswordErr',passwordRules):true;
    if(!v1||!v2) e.preventDefault();
  });
}
document.querySelectorAll('form[id^="upd-"]').forEach(function(form) {
  const uid=form.id.replace('upd-','');
  const uInp=document.querySelector('input[name="new_username"][form="upd-'+uid+'"]');
  const pInp=document.querySelector('input[name="new_password"][form="upd-'+uid+'"]');
  if(uInp) uInp.addEventListener('blur',()=>validateUserField(uInp,'updUsernameErr'+uid,usernameRules));
  if(pInp) pInp.addEventListener('blur',()=>validateUserField(pInp,'updPasswordErr'+uid,passwordRules));
  form.addEventListener('submit',function(e){
    const v1=uInp?validateUserField(uInp,'updUsernameErr'+uid,usernameRules):true;
    const v2=pInp?validateUserField(pInp,'updPasswordErr'+uid,passwordRules):true;
    if(!v1||!v2) e.preventDefault();
  });
});
</script>
</body>
</html>