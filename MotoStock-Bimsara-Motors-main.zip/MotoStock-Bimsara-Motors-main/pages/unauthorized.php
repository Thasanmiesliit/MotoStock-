<?php
session_start();
if (!isset($_SESSION['userID'])) { header("Location: ../login.php"); exit; }
$base = '../';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Access Denied — MotoStock26</title>
  <link href="https://fonts.googleapis.com/css2?family=Syne:wght@700;800&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/styles.css">
  <style>
    body { display:flex; align-items:center; justify-content:center; min-height:100vh; background:var(--bg); }
    .unauth-box { text-align:center; max-width:420px; padding:48px 40px; background:var(--card-bg); border:1px solid var(--border); border-radius:16px; }
    .unauth-icon { font-size:4rem; margin-bottom:16px; }
    .unauth-title { font-family:'Syne',sans-serif; font-size:1.6rem; font-weight:800; margin-bottom:8px; }
    .unauth-sub { color:var(--muted); font-size:.9rem; line-height:1.6; margin-bottom:28px; }
    .unauth-role { display:inline-block; background:var(--surface); border:1px solid var(--border); border-radius:20px; padding:4px 14px; font-size:.78rem; color:var(--muted); margin-bottom:24px; }
  </style>
</head>
<body>
  <div class="unauth-box">
    <div class="unauth-icon">🚫</div>
    <div class="unauth-title">Access Denied</div>
    <div class="unauth-sub">You don't have permission to view this page.</div>
    <div class="unauth-role">Logged in as: <strong><?= htmlspecialchars($_SESSION['role']) ?></strong></div>
    <br>
    <a href="../pages/dashboard.php" class="btn btn-amber">Go to Dashboard</a>
  </div>
</body>
</html>