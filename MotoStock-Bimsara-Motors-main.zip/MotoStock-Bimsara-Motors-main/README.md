# 🏍️ MotoStock — Setup Guide

**Bike Repair \& Parts Management System**
*Developed for Bimsara Motors*

\---

## Before You Start

Make sure you have the following ready:

* The **MotoStock26 zip file** (provided by your developer)
* A **Windows laptop or PC**
* A stable internet connection (only needed during setup)

Estimated setup time: **10–15 minutes**

\---

## Step 1 — Extract the System Files

1. Right-click the zip file you received
2. Click **Extract All…**
3. Choose a location you can easily find (e.g. your Desktop)
4. Click **Extract**

You will see a folder called **MotoStock26** appear. Leave it there for now.

\---

## Step 2 — Download and Install XAMPP

XAMPP is the free server software that runs MotoStock26 on your computer.

1. Open your browser and go to:
👉 **https://www.apachefriends.org/download.html**
2. Download the **latest Windows version**
3. Once downloaded, run the installer file
4. If Windows asks *"Do you want to allow this app to make changes?"* — click **Yes**
5. Follow the installer steps and click **Next** through each screen
6. When it finishes, click **Finish** — XAMPP will open automatically

> ⚠️ If your antivirus blocks the installer, temporarily disable it during installation, then re-enable it after.

\---

## Step 3 — Copy the System Files into XAMPP

1. Open the **MotoStock26** folder you extracted in Step 1
2. Inside it, find the folder named **MotoStock26** — copy this inner folder
3. Now navigate to: **C: → xampp → htdocs**
4. Paste the copied **MotoStock26** folder inside **htdocs**

Your final path should look like this:

```
C:\\xampp\\htdocs\\MotoStock26\\
```

\---

## Step 4 — Start the XAMPP Server

1. Open the **XAMPP Control Panel** (search for it in your Start menu if it's not open)
2. Click the **Start** button next to **Apache**
3. Click the **Start** button next to **MySQL**
4. Both should turn **green** with the status showing *Running*

> ⚠️ If Apache fails to start, another program may be using Port 80 (commonly Skype or IIS). Restart your PC and try again, or contact your developer.

\---

## Step 5 — Set Up the Database

This step loads all the system's data tables into your computer.

1. Open your browser and go to:
👉 **http://localhost/phpmyadmin/**
2. On the left side panel, click **New** to create a new database
3. In the *Database name* field, type exactly:

```
   motostock26
   ```

   Then click **Create**

4. You should now see **motostock26** selected on the left panel
5. Click the **SQL** tab at the top of the page
6. Go back to your **MotoStock26** folder and open the file named **sqlsetup.txt** using Notepad
7. Press **Ctrl + A** to select everything, then **Ctrl + C** to copy it
8. Go back to phpMyAdmin and click inside the SQL text box, then press **Ctrl + V** to paste
9. Click the **Go** button on the bottom right
10. Wait a moment — you should see a green success message. Your database is now ready.

    \---

    ## Step 6 — Open MotoStock26

1. Open a new tab in your browser
2. Go to:
👉 **http://localhost/MotoStock26/login.php**
3. You should see the MotoStock26 login page

   \---

   ## Step 7 — First Login

   Log in using the default owner credentials:

|Field|Value|
|-|-|
|Username|`owner1`|
|Password|`password`|

> 🔐 \*\*Important:\*\* Change your password immediately after your first login. Go to \*\*User Info → Manage Accounts\*\* to update it.

\---

## Step 8 — Set Up Your Email (For Notifications)

MotoStock26 can automatically send email notifications for service reminders, low stock alerts, and completed sales. To enable this:

1. After logging in, click your **username** in the sidebar (bottom left)
2. Go to **User Info**
3. Find the **Email \& Notification Settings** section
4. Follow the on-screen instructions to enter your Gmail address and App Password

> The page includes a full step-by-step guide on how to generate a Google App Password. It takes about 2 minutes.

\---

## ✅ Setup Complete!

MotoStock26 is now running on your computer. Here's a quick summary of what you can do:

|Module|What it does|
|-|-|
|🔧 Repair Jobs|Track all bike repair jobs and their status|
|👥 Customers|Manage customer records and service due dates|
|📦 Inventory|Track spare parts and get low stock alerts|
|🛒 Purchase Orders|Record orders from suppliers|
|🧾 Sales / POS|Create invoices and process sales|
|📊 Reports|View analytics for each module|
|✉️ Notifications|Send automatic email alerts|

\---

## ❓ Troubleshooting

**The login page is not loading**

* Make sure both Apache and MySQL are showing *Running* (green) in XAMPP Control Panel
* Check that the folder is at `C:\\xampp\\htdocs\\MotoStock26\\` exactly (spelling and capitals matter)

**Apache won't start**

* Another program is using Port 80. Try restarting your PC first
* If it still fails, contact your developer

**The database setup showed errors**

* Make sure you selected the `motostock26` database on the left before running the SQL
* Try clicking **Go** again — some warnings are safe to ignore as long as the tables were created

**I forgot my password**

* Open phpMyAdmin → select `motostock26` → click the `user` table → find your account and edit the password field directly

\---

*For any technical issues, contact your developer.
MotoStock — Version 2.23*

